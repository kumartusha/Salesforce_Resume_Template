import { LightningElement, api } from "lwc";

export default class Error extends LightningElement {
    @api message
}